package br.com.acc.bancoonline.exceptions;

public class SaqueParaMesmaPessoaException extends Exception{
    public SaqueParaMesmaPessoaException() {
        super("Você não pode transferir para você mesmo.");
    }
}
