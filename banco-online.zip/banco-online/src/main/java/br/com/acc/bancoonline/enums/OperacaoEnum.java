package br.com.acc.bancoonline.enums;

public enum OperacaoEnum {
    SAQUE, DEPOSITO, TRANFERENCIA
}
