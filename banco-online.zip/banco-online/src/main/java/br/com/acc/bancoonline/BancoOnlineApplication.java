package br.com.acc.bancoonline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import br.com.acc.bancoonline.model.Cliente;
import br.com.acc.bancoonline.repository.ClienteRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
@SpringBootApplication
public class BancoOnlineApplication {

    public static void main(String[] args) {
        SpringApplication.run(BancoOnlineApplication.class, args);
    }

    @Bean
    public CommandLineRunner demo(ClienteRepository clienteRepository) {
        return (args) -> {
            // CPF do cliente que desejamos inserir
            String cpf = "123.456.789-01";

            // Verifica se um cliente com esse CPF já existe
            Cliente existingCliente = clienteRepository.findByCpf(cpf);

            if (existingCliente == null) {
                // Cria um novo cliente e salva no banco de dados
                Cliente cliente = new Cliente();
                cliente.setNome("João da Silva");
                cliente.setCpf(cpf);
                cliente.setTelefone("11987654321");
                clienteRepository.save(cliente);
            }
        };
    }

}
