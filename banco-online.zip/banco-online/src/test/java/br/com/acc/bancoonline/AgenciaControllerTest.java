package br.com.acc.bancoonline;

import br.com.acc.bancoonline.controller.AgenciaController;
import br.com.acc.bancoonline.dto.AgenciaDTO;
import br.com.acc.bancoonline.exceptions.AgenciaNaoEncontradaException;
import br.com.acc.bancoonline.exceptions.CampoVazioGenericoException;
import br.com.acc.bancoonline.exceptions.ClienteNaoEncontradoException;
import br.com.acc.bancoonline.model.Agencia;
import br.com.acc.bancoonline.service.AgenciaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.OK;

class AgenciaControllerTest {

    @Mock
    private AgenciaService service;

    @InjectMocks
    private AgenciaController controller;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateAgenciaSuccess() throws CampoVazioGenericoException, ClienteNaoEncontradoException {
        // Cria um DTO de agência de teste
        AgenciaDTO dto = new AgenciaDTO("Agencia Central", "Rua Principal, 123", "123456789");

        // Configura o comportamento do mock
        doNothing().when(service).create(dto);

        // Chama o método de criação
        ResponseEntity<Void> response = controller.create(dto);

        // Verifica se o status da resposta está correto
        assertEquals(CREATED, response.getStatusCode());
        // Verifica se o serviço foi chamado uma vez
        verify(service, times(1)).create(dto);
    }

    @Test
    void testFindByIdSuccess() throws AgenciaNaoEncontradaException {
        // Cria uma agência de teste
        Agencia agencia = new Agencia();

        // Configura o comportamento do mock
        when(service.findById(1)).thenReturn(agencia);

        // Chama o método de busca por ID
        ResponseEntity<Agencia> response = controller.findById(1);

        // Verifica se o status da resposta e o corpo estão corretos
        assertEquals(OK, response.getStatusCode());
        assertEquals(agencia, response.getBody());
    }

    @Test
    void testFindAll() {
        // Cria uma lista de agências de teste
        List<Agencia> agencias = List.of(
                new Agencia(),
                new Agencia()
        );

        // Configura o comportamento do mock
        when(service.findAll()).thenReturn(agencias);

        // Chama o método de busca por todas as agências
        ResponseEntity<List<Agencia>> response = controller.findAll();

        // Verifica se o status da resposta e o corpo estão corretos
        assertEquals(OK, response.getStatusCode());
        assertEquals(agencias, response.getBody());
    }

    @Test
    void testUpdateAgenciaSuccess() throws CampoVazioGenericoException, AgenciaNaoEncontradaException, ClienteNaoEncontradoException {
        // Cria um DTO de agência de teste
        AgenciaDTO dto = new AgenciaDTO("Agencia Central", "Rua Principal, 123", "123456789");

        // Cria uma agência de teste
        Agencia updatedAgencia = new Agencia();

        // Configura o comportamento do mock
        when(service.update(1, dto)).thenReturn(updatedAgencia);

        // Chama o método de atualização
        ResponseEntity<Agencia> response = controller.update(1, dto);

        // Verifica se o status da resposta e o corpo estão corretos
        assertEquals(OK, response.getStatusCode());
        assertEquals(updatedAgencia, response.getBody());
    }

    @Test
    void testDeleteByIdSuccess() throws AgenciaNaoEncontradaException {
        // Configura o comportamento do mock
        doNothing().when(service).deleteById(1);

        // Chama o método de exclusão por ID
        ResponseEntity<Void> response = controller.deleteById(1);

        // Verifica se o status da resposta está correto
        assertEquals(OK, response.getStatusCode());
        // Verifica se o serviço foi chamado uma vez
        verify(service, times(1)).deleteById(1);
    }
}
