package br.com.acc.bancoonline;
import br.com.acc.bancoonline.controller.ExtratoController;
import br.com.acc.bancoonline.dto.ExtratoDTO;
import br.com.acc.bancoonline.exceptions.CampoVazioGenericoException;
import br.com.acc.bancoonline.exceptions.ContaCorrenteNaoEncontradaException;
import br.com.acc.bancoonline.exceptions.ExtratoNaoEncontradoException;
import br.com.acc.bancoonline.model.ContaCorrente;
import br.com.acc.bancoonline.model.Extrato;
import br.com.acc.bancoonline.service.ExtratoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.OK;

class ExtratoControllerTest {

    @Mock
    private ExtratoService service;

    @InjectMocks
    private ExtratoController controller;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateExtratoSuccess() throws CampoVazioGenericoException, ContaCorrenteNaoEncontradaException {
        // Cria um DTO de extrato de teste
        ExtratoDTO dto = new ExtratoDTO(LocalDateTime.now(), "Depósito", 100.0, 1);
        // Configura o comportamento do mock
        doNothing().when(service).create(dto);

        // Chama o método de criação
        ResponseEntity<Void> response = controller.create(dto);

        // Verifica se o status da resposta está correto
        assertEquals(CREATED, response.getStatusCode());
        // Verifica se o serviço foi chamado uma vez
        verify(service, times(1)).create(dto);
    }

    @Test
    void testFindByIdSuccess() throws ExtratoNaoEncontradoException {
        // Cria um extrato de teste
        ContaCorrente contaCorrente = new ContaCorrente();
        Extrato extrato = new Extrato(1, LocalDateTime.now(), "Depósito", 100.0, contaCorrente);

        // Configura o comportamento do mock
        when(service.findById(1)).thenReturn(extrato);

        // Chama o método de busca por ID
        ResponseEntity<Extrato> response = controller.findById(1);

        // Verifica se o status da resposta e o corpo estão corretos
        assertEquals(OK, response.getStatusCode());
        assertEquals(extrato, response.getBody());
    }

    @Test
    void testFindAll() {
        // Cria uma lista de extratos de teste
        ContaCorrente contaCorrente = new ContaCorrente();
        List<Extrato> extratos = List.of(new Extrato(1, LocalDateTime.now(), "Depósito", 100.0, contaCorrente));

        // Configura o comportamento do mock
        when(service.findAll()).thenReturn(extratos);

        // Chama o método de busca por todos
        ResponseEntity<List<Extrato>> response = controller.findAll();

        // Verifica se o status da resposta e o corpo estão corretos
        assertEquals(OK, response.getStatusCode());
        assertEquals(extratos, response.getBody());
    }

    @Test
    void testDeleteByIdSuccess() throws ExtratoNaoEncontradoException {
        // Configura o comportamento do mock
        doNothing().when(service).deleteById(1);

        // Chama o método de exclusão por ID
        ResponseEntity<Void> response = controller.deleteById(1);

        // Verifica se o status da resposta está correto
        assertEquals(OK, response.getStatusCode());
        // Verifica se o serviço foi chamado uma vez
        verify(service, times(1)).deleteById(1);
    }

    @Test
    void testFindAllByContaCorrenteIdSuccess() throws ExtratoNaoEncontradoException {
        // Cria uma lista de extratos de teste
        ContaCorrente contaCorrente = new ContaCorrente();
        List<Extrato> extratos = List.of(new Extrato(1, LocalDateTime.now(), "Depósito", 100.0, contaCorrente));

        // Configura o comportamento do mock
        when(service.findAllByContaCorrenteId(1)).thenReturn(extratos);

        // Chama o método de busca por ID da conta corrente
        ResponseEntity<List<Extrato>> response = controller.findAllByContaCorrenteId(1);

        // Verifica se o status da resposta e o corpo estão corretos
        assertEquals(OK, response.getStatusCode());
        assertEquals(extratos, response.getBody());
    }
}
