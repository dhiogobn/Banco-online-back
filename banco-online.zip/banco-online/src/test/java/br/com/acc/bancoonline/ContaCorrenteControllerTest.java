package br.com.acc.bancoonline;
import br.com.acc.bancoonline.controller.ContaCorrenteController;
import br.com.acc.bancoonline.dto.ContaCorrenteDTO;
import br.com.acc.bancoonline.exceptions.*;
import br.com.acc.bancoonline.model.ContaCorrente;
import br.com.acc.bancoonline.service.ContaCorrenteService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class ContaCorrenteControllerTest {

    private MockMvc mockMvc;

    @Mock
    private ContaCorrenteService service;

    @InjectMocks
    private ContaCorrenteController controller;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
    }

    @Test
    void testCreate() throws Exception {
        ContaCorrenteDTO contaCorrenteDTO = new ContaCorrenteDTO();
        // Configure o DTO conforme necessário para o teste
        doNothing().when(service).create(any(ContaCorrenteDTO.class));

        mockMvc.perform(post("/api/contaCorrentes")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"campo1\":\"valor1\", \"campo2\":\"valor2\"}")) // substitua pelos campos reais do DTO
                .andExpect(status().isCreated());
    }

    @Test
    void testFindById() throws Exception {
        ContaCorrente contaCorrente = new ContaCorrente();
        // Configure a conta conforme necessário para o teste
        when(service.findById(anyInt())).thenReturn(contaCorrente);

        mockMvc.perform(get("/api/contaCorrentes/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.campo1").value("valor1")); // substitua pelos campos reais da resposta
    }

    @Test
    void testFindAll() throws Exception {
        List<ContaCorrente> contaCorrentes = Collections.singletonList(new ContaCorrente());
        when(service.findAll()).thenReturn(contaCorrentes);

        mockMvc.perform(get("/api/contaCorrentes"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].campo1").value("valor1")); // substitua pelos campos reais da resposta
    }

    @Test
    void testUpdate() throws Exception {
        ContaCorrente contaCorrente = new ContaCorrente();
        when(service.update(anyInt(), any(ContaCorrenteDTO.class))).thenReturn(contaCorrente);

        mockMvc.perform(put("/api/contaCorrentes/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"campo1\":\"valor1\", \"campo2\":\"valor2\"}")) // substitua pelos campos reais do DTO
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.campo1").value("valor1")); // substitua pelos campos reais da resposta
    }

    @Test
    void testDeleteById() throws Exception {
        doNothing().when(service).deleteById(anyInt());

        mockMvc.perform(delete("/api/contaCorrentes/1"))
                .andExpect(status().isOk());
    }

    @Test
    void testConsultarDadosDaConta() throws Exception {
        ContaCorrente contaCorrente = new ContaCorrente();
        when(service.getContaByCpf(anyString())).thenReturn(contaCorrente);

        mockMvc.perform(get("/api/contaCorrentes/consultarDadosDaConta/12345678900"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.campo1").value("valor1")); // substitua pelos campos reais da resposta
    }

    @Test
    void testDepositar() throws Exception {
        when(service.depositar(anyInt(), anyDouble())).thenReturn(100.0);

        mockMvc.perform(patch("/api/contaCorrentes/depositar/1/50")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string("100.0"));
    }

    @Test
    void testSacar() throws Exception {
        when(service.sacar(anyInt(), anyDouble())).thenReturn(50.0);

        mockMvc.perform(patch("/api/contaCorrentes/sacar/1/50")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string("50.0"));
    }

    @Test
    void testTransferir() throws Exception {
        when(service.transferir(anyDouble(), anyInt(), anyString())).thenReturn(200.0);

        mockMvc.perform(patch("/api/contaCorrentes/transferir/100/1/12345678900")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string("200.0"));
    }
}
