package br.com.acc.bancoonline;
import br.com.acc.bancoonline.controller.ContaCorrenteController;
import br.com.acc.bancoonline.dto.ContaCorrenteDTO;
import br.com.acc.bancoonline.model.ContaCorrente;
import br.com.acc.bancoonline.service.ContaCorrenteService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.mockito.ArgumentMatchers.any;


import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.hamcrest.Matchers.*;

@SpringBootTest
public class ContaCorrenteControllerTest {

    private MockMvc mockMvc;

    @Mock
    private ContaCorrenteService service;

    @InjectMocks
    private ContaCorrenteController controller;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
    }

    @Test
    public void testCreateContaCorrente() throws Exception {
        ContaCorrenteDTO contaCorrenteDTO = new ContaCorrenteDTO();
        contaCorrenteDTO.setAgencia("1234");
        contaCorrenteDTO.setNumero("56789");
        contaCorrenteDTO.setSaldo(1000.0);

        doNothing().when(service).create(any(ContaCorrenteDTO.class));

        mockMvc.perform(post("/api/contaCorrentes")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"agencia\":\"1234\", \"numero\":\"56789\", \"saldo\":1000.0}"))
                .andExpect(status().isCreated());
    }

    @Test
    public void testFindContaCorrenteById() throws Exception {
        ContaCorrente contaCorrente = new ContaCorrente();
        contaCorrente.setId(1);
        contaCorrente.setAgencia("1234");
        contaCorrente.setNumero("56789");
        contaCorrente.setSaldo(1000.0);

        when(service.findById(1)).thenReturn(contaCorrente);

        mockMvc.perform(get("/api/contaCorrentes/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.agencia", is("1234")))
                .andExpect(jsonPath("$.numero", is("56789")))
                .andExpect(jsonPath("$.saldo", is(1000.0)));
    }

    @Test
    public void testFindAllContaCorrentes() throws Exception {
        ContaCorrente conta1 = new ContaCorrente();
        conta1.setId(1);
        conta1.setAgencia("1234");
        conta1.setNumero("56789");
        conta1.setSaldo(1000.0);

        ContaCorrente conta2 = new ContaCorrente();
        conta2.setId(2);
        conta2.setAgencia("9876");
        conta2.setNumero("54321");
        conta2.setSaldo(2000.0);

        List<ContaCorrente> contas = Arrays.asList(conta1, conta2);

        when(service.findAll()).thenReturn(contas);

        mockMvc.perform(get("/api/contaCorrentes"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].id", is(1)))
                .andExpect(jsonPath("$[1].id", is(2)));
    }

    @Test
    public void testUpdateContaCorrente() throws Exception {
        ContaCorrenteDTO contaCorrenteDTO = new ContaCorrenteDTO();
        contaCorrenteDTO.setAgencia("1234");
        contaCorrenteDTO.setNumero("56789");
        contaCorrenteDTO.setSaldo(1500.0);

        ContaCorrente contaCorrente = new ContaCorrente();
        contaCorrente.setId(1);
        contaCorrente.setAgencia("1234");
        contaCorrente.setNumero("56789");
        contaCorrente.setSaldo(1500.0);

        when(service.update(eq(1), any(ContaCorrenteDTO.class))).thenReturn(contaCorrente);

        mockMvc.perform(put("/api/contaCorrentes/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"agencia\":\"1234\", \"numero\":\"56789\", \"saldo\":1500.0}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.saldo", is(1500.0)));
    }

    @Test
    public void testDeleteContaCorrente() throws Exception {
        doNothing().when(service).deleteById(1);

        mockMvc.perform(delete("/api/contaCorrentes/1"))
                .andExpect(status().isOk());
    }

    @Test
    public void testConsultarDadosDaConta() throws Exception {
        ContaCorrente contaCorrente = new ContaCorrente();
        contaCorrente.setId(1);
        contaCorrente.setAgencia("1234");
        contaCorrente.setNumero("56789");
        contaCorrente.setSaldo(1000.0);

        when(service.getContaByCpf("12345678900")).thenReturn(contaCorrente);

        mockMvc.perform(get("/api/contaCorrentes/consultarDadosDaConta/12345678900"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.agencia", is("1234")))
                .andExpect(jsonPath("$.numero", is("56789")))
                .andExpect(jsonPath("$.saldo", is(1000.0)));
    }

    @Test
    public void testDepositar() throws Exception {
        when(service.depositar(1, 500.0)).thenReturn(1500.0);

        mockMvc.perform(patch("/api/contaCorrentes/depositar/1/500.0"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", is(1500.0)));
    }

    @Test
    public void testSacar() throws Exception {
        when(service.sacar(1, 500.0)).thenReturn(500.0);

        mockMvc.perform(patch("/api/contaCorrentes/sacar/1/500.0"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", is(500.0)));
    }

    @Test
    public void testTransferir() throws Exception {
        when(service.transferir(500.0, 1, "09876543211")).thenReturn(500.0);

        mockMvc.perform(patch("/api/contaCorrentes/transferir/500.0/1/09876543211"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", is(500.0)));
    }
}
