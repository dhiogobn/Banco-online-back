package br.com.acc.bancoonline;

import br.com.acc.bancoonline.dto.ClienteDTO;
import br.com.acc.bancoonline.exceptions.CampoVazioGenericoException;
import br.com.acc.bancoonline.exceptions.ClienteNaoEncontradoException;
import br.com.acc.bancoonline.exceptions.CpfInvalidoException;
import br.com.acc.bancoonline.model.Cliente;
import br.com.acc.bancoonline.repository.ClienteRepository;
import br.com.acc.bancoonline.service.ClienteService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ClienteServiceTest {

    @Mock
    private ClienteRepository repository;

    @InjectMocks
    private ClienteService service;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateClienteSuccess() throws CampoVazioGenericoException, CpfInvalidoException {
        // Cria um DTO de cliente válido
        ClienteDTO clienteDTO = new ClienteDTO("João Silva", "123456789", "12345678900");

        // Configura o comportamento do mock
        when(repository.save(any(Cliente.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Chama o método de criação
        service.create(clienteDTO);

        // Verifica se o método save foi chamado uma vez
        verify(repository, times(1)).save(any(Cliente.class));
    }

    @Test
    void testCreateClienteThrowsCampoVazioGenericoException() {
        // Cria um DTO de cliente com campos vazios
        ClienteDTO clienteDTO = new ClienteDTO(null, null, null);

        // Verifica se a exceção é lançada
        assertThrows(CampoVazioGenericoException.class, () -> service.create(clienteDTO));
    }

    @Test
    void testCreateClienteThrowsCpfInvalidoException() {
        // Cria um DTO de cliente com CPF inválido
        ClienteDTO clienteDTO = new ClienteDTO("João Silva", "123456789", "123");

        // Verifica se a exceção é lançada
        assertThrows(CpfInvalidoException.class, () -> service.create(clienteDTO));
    }

    @Test
    void testFindByIdSuccess() throws ClienteNaoEncontradoException {
        // Cria um cliente de teste
        Cliente cliente = new Cliente(1, "João Silva", "123456789", "12345678900");

        // Configura o comportamento do mock
        when(repository.findById(1)).thenReturn(Optional.of(cliente));

        // Chama o método de busca por ID
        Cliente foundCliente = service.findById(1);

        // Verifica se o cliente encontrado é o correto
        assertEquals(cliente, foundCliente);
    }

    @Test
    void testFindByIdThrowsClienteNaoEncontradoException() {
        // Configura o comportamento do mock para retornar vazio
        when(repository.findById(1)).thenReturn(Optional.empty());

        // Verifica se a exceção é lançada
        assertThrows(ClienteNaoEncontradoException.class, () -> service.findById(1));
    }

    @Test
    void testFindByCpfSuccess() throws ClienteNaoEncontradoException {
        // Cria um cliente de teste
        Cliente cliente = new Cliente(1, "João Silva", "123456789", "12345678900");

        // Configura o comportamento do mock
        when(repository.findByCpf("12345678900")).thenReturn(cliente);

        // Chama o método de busca por CPF
        Cliente foundCliente = service.findByCpf("12345678900");

        // Verifica se o cliente encontrado é o correto
        assertEquals(cliente, foundCliente);
    }

    @Test
    void testFindByCpfThrowsClienteNaoEncontradoException() {
        // Configura o comportamento do mock para retornar nulo
        when(repository.findByCpf("12345678900")).thenReturn(null);

        // Verifica se a exceção é lançada
        assertThrows(ClienteNaoEncontradoException.class, () -> service.findByCpf("12345678900"));
    }

    @Test
    void testFindAll() {
        // Cria uma lista de clientes de teste
        List<Cliente> clientes = List.of(
                new Cliente(1, "João Silva", "123456789", "12345678900"),
                new Cliente(2, "Maria Oliveira", "987654321", "09876543211")
        );

        // Configura o comportamento do mock
        when(repository.findAll()).thenReturn(clientes);

        // Chama o método de busca por todos os clientes
        List<Cliente> foundClientes = service.findAll();

        // Verifica se a lista encontrada é a correta
        assertEquals(clientes, foundClientes);
    }

    @Test
    void testUpdateClienteSuccess() throws ClienteNaoEncontradoException, CampoVazioGenericoException, CpfInvalidoException {
        // Cria um cliente de teste
        Cliente cliente = new Cliente(1, "João Silva", "123456789", "12345678900");

        // Cria um DTO de cliente atualizado
        ClienteDTO updatedDTO = new ClienteDTO("João da Silva", "987654321", "09876543211");

        // Configura o comportamento do mock
        when(repository.findById(1)).thenReturn(Optional.of(cliente));
        when(repository.save(any(Cliente.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // Chama o método de atualização
        Cliente updatedCliente = service.update(1, updatedDTO);

        // Verifica se os campos foram atualizados corretamente
        assertEquals(updatedDTO.getNome(), updatedCliente.getNome());
        assertEquals(updatedDTO.getTelefone(), updatedCliente.getTelefone());
        assertEquals(updatedDTO.getCpf(), updatedCliente.getCpf());
    }

    @Test
    void testDeleteByIdSuccess() throws ClienteNaoEncontradoException {
        // Cria um cliente de teste
        Cliente cliente = new Cliente(1, "João Silva", "123456789", "12345678900");

        // Configura o comportamento do mock
        when(repository.findById(1)).thenReturn(Optional.of(cliente));
        doNothing().when(repository).delete(cliente);

        // Chama o método de exclusão por ID
        service.deleteById(1);

        // Verifica se o método delete foi chamado uma vez
        verify(repository, times(1)).delete(cliente);
    }
}
