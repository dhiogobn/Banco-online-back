package br.com.acc.bancoonline;
import br.com.acc.bancoonline.controller.ClienteController;
import br.com.acc.bancoonline.dto.ClienteDTO;
import br.com.acc.bancoonline.exceptions.CampoVazioGenericoException;
import br.com.acc.bancoonline.exceptions.ClienteNaoEncontradoException;
import br.com.acc.bancoonline.exceptions.CpfInvalidoException;
import br.com.acc.bancoonline.model.Cliente;
import br.com.acc.bancoonline.service.ClienteService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.springframework.http.HttpStatus.*;

class ClienteControllerTest {

    @Mock
    private ClienteService service;

    @InjectMocks
    private ClienteController controller;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateClienteSuccess() throws CampoVazioGenericoException, CpfInvalidoException {
        // Cria um DTO de cliente válido
        ClienteDTO dto = new ClienteDTO("Nome", "123456789", "12345678901");

        // Configura o mock para não fazer nada
        doNothing().when(service).create(dto);

        // Chama o método de criação do controlador
        ResponseEntity<Void> response = controller.create(dto);

        // Verifica se o código de status é CREATED
        assertEquals(CREATED, response.getStatusCode());

        // Verifica se o método create do serviço foi chamado uma vez
        verify(service, times(1)).create(dto);
    }

    @Test
    void testCreateClienteThrowsCampoVazioGenericoException() throws CampoVazioGenericoException, CpfInvalidoException {
        // Cria um DTO de cliente com campos vazios
        ClienteDTO dto = new ClienteDTO(null, null, null);

        // Configura o mock para lançar exceção
        doThrow(new CampoVazioGenericoException()).when(service).create(dto);

        // Chama o método de criação do controlador
        ResponseEntity<Void> response = controller.create(dto);

        // Verifica se o código de status é BAD_REQUEST
        assertEquals(BAD_REQUEST, response.getStatusCode());
    }

    @Test
    void testCreateClienteThrowsCpfInvalidoException() throws CampoVazioGenericoException, CpfInvalidoException {
        // Cria um DTO de cliente com CPF inválido
        ClienteDTO dto = new ClienteDTO("Nome", "123456789", "123");

        // Configura o mock para lançar exceção
        doThrow(new CpfInvalidoException()).when(service).create(dto);

        // Chama o método de criação do controlador
        ResponseEntity<Void> response = controller.create(dto);

        // Verifica se o código de status é BAD_REQUEST
        assertEquals(BAD_REQUEST, response.getStatusCode());
    }

    @Test
    void testFindByIdSuccess() throws ClienteNaoEncontradoException {
        // Cria um cliente de teste
        Cliente cliente = new Cliente(1, "Nome", "123456789", "12345678901");

        // Configura o mock para retornar o cliente
        when(service.findById(1)).thenReturn(cliente);

        // Chama o método de busca por ID do controlador
        ResponseEntity<Cliente> response = controller.findById(1);

        // Verifica se o código de status é OK
        assertEquals(OK, response.getStatusCode());

        // Verifica se o corpo da resposta é o cliente esperado
        assertEquals(cliente, response.getBody());
    }

    @Test
    void testFindByIdThrowsClienteNaoEncontradoException() throws ClienteNaoEncontradoException {
        // Configura o mock para lançar exceção
        when(service.findById(1)).thenThrow(new ClienteNaoEncontradoException());

        // Chama o método de busca por ID do controlador
        ResponseEntity<Cliente> response = controller.findById(1);

        // Verifica se o código de status é NOT_FOUND
        assertEquals(NOT_FOUND, response.getStatusCode());
    }

    @Test
    void testFindByCpfSuccess() throws ClienteNaoEncontradoException {
        // Cria um cliente de teste
        Cliente cliente = new Cliente(1, "Nome", "123456789", "12345678901");

        // Configura o mock para retornar o cliente
        when(service.findByCpf("12345678901")).thenReturn(cliente);

        // Chama o método de busca por CPF do controlador
        ResponseEntity<Cliente> response = controller.findByCpf("12345678901");

        // Verifica se o código de status é OK
        assertEquals(OK, response.getStatusCode());

        // Verifica se o corpo da resposta é o cliente esperado
        assertEquals(cliente, response.getBody());
    }

    @Test
    void testFindByCpfThrowsClienteNaoEncontradoException() throws ClienteNaoEncontradoException {
        // Configura o mock para lançar exceção
        when(service.findByCpf("12345678901")).thenThrow(new ClienteNaoEncontradoException());

        // Chama o método de busca por CPF do controlador
        ResponseEntity<Cliente> response = controller.findByCpf("12345678901");

        // Verifica se o código de status é NOT_FOUND
        assertEquals(NOT_FOUND, response.getStatusCode());
    }

    @Test
    void testFindAll() {
        // Cria uma lista de clientes de teste
        List<Cliente> clientes = List.of(new Cliente(1, "Nome", "123456789", "12345678901"));

        // Configura o mock para retornar a lista de clientes
        when(service.findAll()).thenReturn(clientes);

        // Chama o método de busca por todos os clientes do controlador
        ResponseEntity<List<Cliente>> response = controller.findAll();

        // Verifica se o código de status é OK
        assertEquals(OK, response.getStatusCode());

        // Verifica se o corpo da resposta é a lista esperada
        assertEquals(clientes, response.getBody());
    }

    @Test
    void testDeleteByIdSuccess() throws ClienteNaoEncontradoException {
        // Configura o mock para não fazer nada
        doNothing().when(service).deleteById(1);

        // Chama o método de exclusão por ID do controlador
        ResponseEntity<Void> response = controller.deleteById(1);

        // Verifica se o código de status é OK
        assertEquals(OK, response.getStatusCode());

        // Verifica se o método deleteById do serviço foi chamado uma vez
        verify(service, times(1)).deleteById(1);
    }

    @Test
    void testDeleteByIdThrowsClienteNaoEncontradoException() throws ClienteNaoEncontradoException {
        // Configura o mock para lançar exceção
        doThrow(new ClienteNaoEncontradoException()).when(service).deleteById(1);

        // Chama o método de exclusão por ID do controlador
        ResponseEntity<Void> response = controller.deleteById(1);

        // Verifica se o código de status é NOT_FOUND
        assertEquals(NOT_FOUND, response.getStatusCode());
    }
}
